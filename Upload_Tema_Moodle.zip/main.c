#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "PARTICIPANT.h"
#include "QUEUE.h"
#include "BST.h"
#include "HEAP.h"
#include "GRAPH.h"

int main() {

	//Pas 1
	queue_t *q;
	q=createQueueFromFile("./Pas_1/candidati.csv");
	writeQueueToFile(q,"./Pas_1/test_1.csv");

	//Pas 2
	bst_node *root_lord=NULL,*root_others=NULL;
	moveToBst(q,&root_lord,&root_others);
	bstWriteToFile("./Pas_2/test_2_lorzi.csv",root_lord);
	bstWriteToFile("./Pas_2/test_2_cavaleri_aventurieri.csv",root_others);

	//Pas 3
	root_lord=bstDelWithInfoFromFile("./Pas_3/contestatii.csv",root_lord);
	bstWriteToFile("./Pas_3/test_3_lorzi.csv",root_lord);

	//Pas 4
	const int MAX_PARTICIPANTS=8;
	heap_t *h;
	h=createHeap(MAX_PARTICIPANTS);
	selectParticipantsFromTree(h,&root_lord,&root_others);
	printHeapToFile("./Pas_4/test_4.csv",h);

	//Pas 5
	updateHeapAfterHunt(h);
	printHeapToFile("./Pas_5/test_5.csv",h);

	//Pas 6
	const int MAX_WINNERS=3;
	printWinners("./Pas_6/test_6.csv",h,MAX_WINNERS);

	//Pas 7
	graph_t *g;
	int MAX_NODES=11;
	route_t *routes=NULL;
	int no_routes=0;
	g=createGraphFromFile("./Pas_7/drumuri.csv",MAX_NODES);
	findRoutes("./Pas_7/test_7.csv",g,&routes,&no_routes);

	//freeing memory

	//free graph
	freeGraph(g);
	freeRoutes(routes,no_routes);

	//free bst
	bstFree(root_lord);
	bstFree(root_others);

	//free heap
	freeHeap(h);

	//free queue
	freeQueue(q);

	return 0;
}
