#ifndef _ROUTE_H_

#define _ROUTE_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct route_t route_t;

struct route_t
{
    char name[4];
    int *forests;
    int cnt_forests;
};

void copyRoute(route_t *dest,route_t *src);
void readRouteFromFile(FILE **file , route_t *route);
void freeRoutes(route_t* routes, int no_routes);

#endif