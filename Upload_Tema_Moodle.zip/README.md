# Tema PA 2025 - 314AB Mitran Adina

## Descriere
Proiectul implementeaza un sistem pentru gestionarea participantilor intr-o competitie de tip vanatoare. Acesta se ocupa de inregistrarea si selectia candidatilor si de determinarea rutelor acestora.

## Componente de baza
- PARTICIPANT - se ocupa de prelucrarea datelor candidatilor
- QUEUE - se ocupa de inregistrarea candidatilor
- BST - organizeaza candidatii in functie de experienta si statut social (lorzi, respectiv aventurieri si cavaleri)
- ROUTE - se ocupa de prelucrarea datelor legate de trasee
- HEAP - selecteaza cei mai buni inscrisi care vor lua parte la cursa
- GRAPH - gestioneaza sistemul de rute si genereaza trasee

## Implementare
### Pasul 1 - inregistrarea candidatilor
- am implementat o coada pentru a citi datele din "candidati.csv", folosind functia _createQueueFromFile_
- am afisat coada in fisierul "test_1.csv" _writeQueueToFile_

### Pasul 2 - organizarea candidatilor
- am mutat elementele cozii in doi arbori binar de cautare, unul pentru candidatii lorzi (lords) si unul pentru candidatii aventurieri si cavaleri (others), cu ajutorul functiei _moveToBst_
- acestia sunt ordonati dupa experienta

### Pasul 3 - gestionarea contestatiilor
- functia _bstDelete_ se ocupa de stergerea unor noduri dintr-un arbore binar de cautare, iar _bstDelWithInfoFromFile_ sterge strict candidatii care apar in fisierul "contestatii.csv"

### Pasul 4 - selectarea participantilor si asignarea de trasee
- cu functia _getAndDelMaxFromTree_ caut participantul cu experienta cea mai mare dintr-un arbore binar de cautare, functie care este apelata in cadrul _selectParticipantsFromTree_ astfel incat sa fie selectati cei 8 participanti in ordinea specificata (cate un lord si cate un cavaler/aventurier)
- pentru fiecare participant este asignat un traseu, in cadrul functiei _selectParticipantsFromTree_; aici e apelata functia _readRouteFromFile_ pentru a lua datele traseelor din fisierul "trasee.csv"
- dupa ce un participant isi primeste traseul, este introdus in heap (coada cu prioritati) cu ajutorul functiei _insertHeapNode_

### Pasul 5 - actualizarea experientei
- functia _updateHeapAfterHunt_ actualizeaza experienta fiecarui participant (adica adauga punctele fiecarei paduri din traseul sau la experienta sa initiala)
- functia _sortHeap_ sorteaza elementele din heap in ordine descrescatoare dupa experienta (practic, se distruge heap-ul, intrucat isi pierde proprietatile)

### Pasul 6 - premierea
- dupa ce heap-ul a fost sortat, sunt afisati primii 3 participanti cu cea mai mare experienta (cel mai mare punctaj) cu ajutorul _printWinners_; acestia sunt castigatorii vanatorii

### Pasul 7 - generarea traseelor
- este furnizata harta padurilor printr-un graf orientat
- un traseu poate fi generat doar intre un varf cu grad de intrare 0 si unul cu grad de iesire tot 0; in functia _findRoutes_ se cauta sa se indeplineasca aceasta conditie si, in caz afirmativ, se realizeaza o parcurgere in adancime intre cele doua (cu functia _dfsBetween_)
- tot in _findRoutes_ sunt apelate functiile _sortRoutes_, pentru a sorta traseele in ordine lexicografica, si _printRoutesToFile_, pentru a le scrie in fisierul "test_7.csv"

