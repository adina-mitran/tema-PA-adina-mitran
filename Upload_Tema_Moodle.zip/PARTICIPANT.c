#include "PARTICIPANT.h"

void copyParticipant(participant_t *dest,participant_t *src)
{
    if(dest->name!=NULL)
    {
        free(dest->name);
        dest->name=NULL;
    }

    if(src->name!=NULL)
    {
        int name_length=strlen(src->name)+1;
        dest->name=(char*)malloc( name_length * sizeof(char) );
        strcpy(dest->name,src->name);
        dest->age=src->age;
        dest->xp=src->xp;
        dest->status=src->status;
    }

}

int readParticipant(FILE **file,participant_t *p)
{
    int read_count=0;
    char status[16]={0},name[32]={0};

    read_count += fscanf(*file,"%s ", status);
    formatStatus(p,status);

    read_count += fscanf(*file,"%[^;]",name);
    fgetc(*file);

    if(p->name!=NULL)
    {
        free(p->name);
        p->name=NULL;
    }

    int name_length=strlen(name);
    p->name=(char*)malloc((name_length+1)*sizeof(char));
    if(p->name==NULL)
    {
        printf("eroare alocare participant name");
        p->name=NULL;
        return -1;
    }
    strcpy(p->name,name);
    formatName(p->name);

    read_count += fscanf(*file,"%f",&p->xp);
    fgetc(*file);

    read_count += fscanf(*file,"%d",&p->age);
    fgetc(*file);

    return read_count;
}

void formatName(char *name)
{
    int length=strlen(name);
    for(int i=0;i<length;i++)
    {
        if(name[i]==' ')
            name[i]='-';
        else if(name[i]>='a' && name[i]<='z')
        {
            if(i==0 || name[i-1]=='-')
                name[i]-=32;
        }
        else if(name[i]>='A' && name[i]<='Z')
        {
            if(i!=0 && name[i-1]!='-')
                name[i]+=32;
        }
    }
}

void formatStatus(participant_t *person, char *status)
{
    if(status[0]>='A' && status[0]<='Z')
        status[0]+=32;
    person->status=status[0];
}