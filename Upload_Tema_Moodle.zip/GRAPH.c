#include "GRAPH.h"

graph_t *createGraphFromFile(const char* filename, int node_no)
{
    FILE *file=fopen(filename, "rt");
    graph_t *g=(graph_t*)malloc(sizeof(graph_t));
    memset(g,0,sizeof(graph_t));

    g->nodes=node_no;
    g->list=(glist_elem*)malloc(g->nodes * sizeof(glist_elem));
    memset(g->list, 0, g->nodes * sizeof(glist_elem));

    for(int i=0; i < g->nodes;i++)
    {
        g->list[i].data.val=i;
    }

    int start_point, destination;
    while(fscanf(file, "%d %d",&start_point,&destination)==2)
    {
        glist_elem *new=(glist_elem*)malloc(sizeof(glist_elem));
        memset(new, 0, sizeof(glist_elem));

        new->data.val=destination;
        g->list[destination].data.in++;
        g->list[start_point].data.out++;

        addToGraphList(&g->list[start_point],new);

        g->edges++;
    }

    for(int i=0; i < g->nodes ;i++)
    {
        glist_elem *current;
        current=&g->list[i];
        while(current!=NULL)
        {
            current->data = g->list[current->data.val].data;
            current=current->next;
        }
    }
    fclose(file);
    return g;
}

void addToGraphList(glist_elem *list,glist_elem *elem)
{
    glist_elem *current;
    current=list;

    while(current->next!=NULL)
        current=current->next;
    current->next=elem;
}

void printGraph(graph_t *g)
{
    for(int i=0; i < g->nodes; i++)
    {
        glist_elem *p = &g->list[i];
        while(p!=NULL)
        {
            printf("{val=%d,in=%d,out=%d} ", p->data.val, p->data.in, p->data.out);
            p=p->next;
        }
        printf("\n");
    }
}

void freeGraph(graph_t *g)
{
    for(int i=0; i < g->nodes; i++)
    {
        glist_elem *elem,*temp;

        elem=g->list[i].next;

        while(elem!=NULL)
        {
            temp=elem;
            elem=elem->next;
            free(temp);
        }
    }
    free(g->list);
    free(g);
}

void findRoutes(const char *filename, graph_t *g, route_t **routes,int *no_routes)
{
    FILE *file=fopen(filename, "wt");

    int *visited=(int*)malloc(g->nodes*sizeof(int));
    memset(visited, 0, g->nodes*sizeof(int));

    *no_routes=0;
    *routes=NULL;

    for(int i=0;i < g->nodes;i++)
        if(g->list[i].data.in==0)
        {
            for(int j=0; j < g->nodes;j++)
                if(g->list[j].data.out==0)
                {
                    route_t new_route;
                    memset(&new_route,0,sizeof(route_t));
                    new_route.forests=(int*)malloc(g->nodes * sizeof(int));
                    dfsBetween(g,i,j,visited,&new_route,routes,no_routes);

                    free(new_route.forests);
                }
        }

    sortRoutes(*routes,*no_routes);
    printRoutesToFile(file,g,*routes,*no_routes);
    free(visited);
    fclose(file);
}

void dfsBetween(graph_t *g,int current,int destination,int *visited, route_t *r,route_t **routes, int *no_routes)
{
    visited[current]=1;
    r->forests[r->cnt_forests++]=current;

    if(current==destination)
    {
        *routes = (route_t*)realloc(*routes, ((*no_routes) + 1) * sizeof(route_t));
        memset(&(*routes)[(*no_routes)],0,sizeof(route_t));
        copyRoute(&(*routes)[(*no_routes)++], r);
    }
    else
    {
        glist_elem *elem=g->list[current].next;
        while(elem)
        {
            if(visited[elem->data.val]==0)
                dfsBetween(g,elem->data.val,destination,visited,r,routes,no_routes);
            elem=elem->next;
        }
    }
    visited[current]=0;
    r->cnt_forests--;
}

int compareRoutes(route_t r1,route_t r2)
{
    int min_length;
    if (r1.cnt_forests <= r2.cnt_forests)
        min_length = r1.cnt_forests;
    else
        min_length = r2.cnt_forests;

    for (int i = 0; i < min_length; i++)
    {
        if (r1.forests[i] < r2.forests[i]) return -1;
        if (r1.forests[i] > r2.forests[i]) return 1;
    }

    if (r1.cnt_forests < r2.cnt_forests) return -1;
    if (r1.cnt_forests > r2.cnt_forests) return 1;

    return 0;
}

void sortRoutes(route_t *routes,int no_routes)
{
    for(int i=0; i < no_routes-1;i++)
        for(int j=i+1; j < no_routes;j++)
            if(compareRoutes(routes[i],routes[j])>0)
            {
                route_t temp;
                memset(&temp,0,sizeof(route_t));
                temp.forests=NULL;

                copyRoute(&temp,&routes[i]);
                copyRoute(&routes[i],&routes[j]);
                copyRoute(&routes[j],&temp);

                free(temp.forests);
                temp.forests=NULL;
            }
    for(int i=0; i < no_routes; i++)
    {
        int num=i+1;
        routes[i].name[0]='T';

        if(i<10)
        {
            routes[i].name[1]='0'+num;
            routes[i].name[2]='\0';
        }
        else if(i>=10 && i<100)
        {
            routes[i].name[1]='0'+num/10;
            routes[i].name[2]='0'+num%10;
            routes[i].name[3]='\0';
        }
    }
}


void printRoutesToFile(FILE *file, graph_t *g,route_t *routes,int no_routes)
{
    for(int i=0;i<no_routes-1;i++)
    {
        fprintf(file, "%s:",routes[i].name);
        for(int j=0; j < routes[i].cnt_forests;j++)
        {
            fprintf(file, " %d",routes[i].forests[j]);
        }
        fprintf(file, "\n");
    }

    fprintf(file, "%s:",routes[no_routes-1].name);
    for(int j=0; j < routes[no_routes-1].cnt_forests;j++)
    {
        fprintf(file, " %d",routes[no_routes-1].forests[j]);
    }

}
