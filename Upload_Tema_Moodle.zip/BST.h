#ifndef _BST_H_

#define _BST_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "PARTICIPANT.h"
#include "QUEUE.h"

typedef struct bst_node bst_node;
struct bst_node
{
    participant_t data;
    struct bst_node *left,*right;
};

bst_node* newTreeNode(participant_t p);
bst_node* bstInsert(bst_node* tnode,participant_t p);
void moveToBst(queue_t *q,bst_node **root_lord,bst_node **root_others);
void sdrToFile(FILE *file, bst_node *root);
void bstWriteToFile(const char *filename,bst_node *root);
void bstFree(bst_node *root);
bst_node* bstMinValNode(bst_node* tnode);
bst_node* bstDelete(bst_node* tnode, participant_t p);
bst_node* bstMaxValNode(bst_node* tnode);
bst_node* bstDelWithInfoFromFile(const char* filename,bst_node* tnode);


#endif