#include "HEAP.h"

heap_t *createHeap(int capacity)
{
    heap_t *h=(heap_t*)malloc(sizeof(heap_t));
    if(h==NULL)
    {
        printf("eroare spatiu crHeap");
        return NULL;
    }

    h->size=0;
    h->capacity=capacity;
    h->array=(heap_element*)malloc(h->capacity*sizeof(heap_element));
    if(h->array==NULL)
    {
        printf("eroare spatiu vector heap");
        free(h);
        return NULL;
    }

    for(int i=0; i < h->capacity;i++)
    {
        memset(&h->array[i],0,sizeof(heap_element));
        h->array[i].route.forests=NULL;
        h->array[i].participant.name=NULL;
    }
    return h;
}

int leftChild(heap_t *h,int i)
{
    int poz=2*i+1;
    if(poz > h->size-1 || i<0)
        return -1;
    return poz;
}

int rightChild(heap_t *h, int i)
{
    int poz=2*i+2;
    if(poz > h->size-1 || i<0)
        return -1;
    return poz;
}

void copyHeapArrayElem(heap_element *dest,heap_element *src)
{
    copyParticipant(&dest->participant,&src->participant);
    copyRoute(&dest->route,&src->route);
}

void swapHeapElements(heap_element *dest,heap_element *src)
{
    heap_element aux;
    memset(&aux, 0, sizeof(heap_element));
    aux.participant.name=NULL;
    aux.route.forests=NULL;

    copyHeapArrayElem(&aux,dest);
    copyHeapArrayElem(dest,src);
    copyHeapArrayElem(src,&aux);

    free(aux.participant.name);
    free(aux.route.forests);
    aux.participant.name=NULL;
    aux.route.forests=NULL;
}

void heapifyDown(heap_t *h,int i)
{
    int left,right,max=i,aux;
    left=leftChild(h,i);
    right=rightChild(h,i);

    if(left==-1 && right==-1)
        return;
    if(left!=-1 && h->array[left].participant.xp > h->array[max].participant.xp)
        max=left;
    if(right!=-1 && h->array[right].participant.xp > h->array[max].participant.xp)
        max=right;

    if(max!=i)
    {
        swapHeapElements(&h->array[i],&h->array[max]);
        heapifyDown(h,max);
    }

    return;
}

void resizeHeap(heap_t *h)
{
    int i,old_c=h->capacity;
    h->capacity*=2;
    h->array=(heap_element*)realloc(h->array,h->capacity* sizeof(heap_element));

    for(i=old_c;i<h->capacity;i++)
        h->array[i].participant.name=NULL;
}

void insertHeapNode(heap_t *h,heap_element x)
{
    int i;
    if(h->size==h->capacity)
        resizeHeap(h);
    i=h->size;
    h->size++;

    while(i>0 && x.participant.xp > h->array[(i-1)/2].participant.xp)
    {
        copyHeapArrayElem(&h->array[i],&h->array[(i-1)/2]);
        i=(i-1)/2;
    }
    copyHeapArrayElem(&h->array[i],&x);
}

void printHeapToFile(const char *filename,heap_t *h)
{
    FILE* file=fopen(filename,"wt");
    fprintf(file,"Nume_Traseu - Nume_Participant (Experienta_participant)");
    for(int i=0;i < h->size; i++)
    {
        fprintf(file,  "\n%s - %s (%.2f) ", h->array[i].route.name, h->array[i].participant.name, h->array[i].participant.xp);
    }
    fprintf(file, "\n");
    fclose(file);
}

participant_t getAndDelMaxFromTree(bst_node **root)
{
    bst_node *max_tnode=bstMaxValNode(*root);

    participant_t p;
    memset(&p,0,sizeof(participant_t));
    p.name=NULL;

    copyParticipant(&p,&max_tnode->data);
    *root=bstDelete(*root,max_tnode->data);

    return p;
}

void selectParticipantsFromTree(heap_t *h, bst_node **root_lords, bst_node **root_others)
{
    FILE *route_file=fopen("./Pas_4/trasee.csv","rt");
    if(route_file==NULL)
    {
        printf("eroare deschiere fisier trasee");
        return;
    }

    for(int i=0;i<8;i++)
    {
        heap_element elem;
        memset(&elem,0,sizeof(heap_element));
        elem.participant.name=NULL;
        elem.route.forests=NULL;

        participant_t temp_participant;
        memset(&temp_participant,0,sizeof(participant_t));
        temp_participant.name=NULL;

        if(i%2==0)
        {
            temp_participant=getAndDelMaxFromTree(root_lords);
            copyParticipant(&elem.participant,&temp_participant);
        }
        else
        {
            temp_participant=getAndDelMaxFromTree(root_others);
            copyParticipant(&elem.participant,&temp_participant);
        }

        if(temp_participant.name!=NULL)
        {
            free(temp_participant.name);
            temp_participant.name=NULL;
        }

        route_t r;
        memset(&r, 0, sizeof(route_t));
        r.forests=NULL;
        readRouteFromFile(&route_file,&r);

        if(elem.route.forests!=NULL)
        {
            free(elem.route.forests);
            elem.route.forests=NULL;
        }

        copyRoute(&elem.route,&r);

        if(r.forests!=NULL)
        {
            free(r.forests);
            r.forests=NULL;
        }

        insertHeapNode(h,elem);

        if(elem.participant.name!=NULL)
        {
            free(elem.participant.name);
            elem.participant.name=NULL;
        }
        if(elem.route.forests!=NULL)
        {
            free(elem.route.forests);
            elem.route.forests=NULL;
        }
    }
    fclose(route_file);
}

void freeHeap(heap_t *h)
{
    if(h==NULL)
        return;
    if(h->array!=NULL)
    {
        for(int i=0; i < h->capacity; i++)
        {
            if(h->array[i].participant.name!=NULL)
            {
                free(h->array[i].participant.name);
                h->array[i].participant.name=NULL;
            }
            if(h->array[i].route.forests!=NULL)
            {
                free(h->array[i].route.forests);
                h->array[i].route.forests=NULL;
            }
        }
        free(h->array);
        h->array=NULL;
    }
    free(h);
}


void sortHeap(heap_t *h)
{
    if(h==NULL || h->size<=1)
        return;
    int n=h->size;

    for(int i=n-1;i>0;i--)
    {
        swapHeapElements(&h->array[0],&h->array[i]);
        h->size=i;
        heapifyDown(h,0);
    }
    h->size=n;
}
void updateHeapAfterHunt(heap_t *h)
{
    for(int i=0;i<8;i++)
        for(int j=0;j<h->array[i].route.cnt_forests;j++)
            h->array[i].participant.xp += h->array[i].route.forests[j];

    for(int i=(h->size)/2 -1;i>=0;i--)
        heapifyDown(h,i);
}

void printWinners(const char *filename, heap_t *h,int win_no)
{
    FILE *file=fopen(filename, "wt");
    sortHeap(h);
    fprintf(file, "Nume Experienta_totala");
    for(int i=h->size-1 ; i>=h->size-win_no ; i--)
        fprintf(file, "\n%s %.2f",h->array[i].participant.name,h->array[i].participant.xp);
    fclose(file);
}
