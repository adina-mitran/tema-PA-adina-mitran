#ifndef _GRAPH_H_

#define _GRAPH_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ROUTE.h"

typedef struct elem_degree elem_degree;
typedef struct glist_elem glist_elem;
typedef struct graph_t graph_t;
typedef struct groute groute;

struct elem_degree
{
    int val;
    int in,out;
};

struct glist_elem
{
    elem_degree data;
    glist_elem *next;
};

struct graph_t
{
    int nodes, edges;
    glist_elem *list;
};



graph_t *createGraphFromFile(const char* filename, int node_no);
void addToGraphList(glist_elem *list,glist_elem *elem);
void printGraph(graph_t *g);
void freeGraph(graph_t *g);

void findRoutes(const char *filename, graph_t *g, route_t **routes,int *no_routes);
void dfsBetween(graph_t *g,int current,int destination,int *visited, route_t *r,route_t **routes, int *no_routes);
int compareRoutes(route_t r1,route_t r2);
void sortRoutes(route_t *routes,int no_routes);
void printRoutesToFile(FILE *file, graph_t *g,route_t *routes,int no_routes);

#endif