#include "BST.h"

bst_node* newTreeNode(participant_t p)
{
    bst_node* tnode= (bst_node*)malloc(sizeof(bst_node));

    if(tnode==NULL)
    {
        printf("eroare creare nod in bst");
        return 0;
    }

    tnode->data=p;
    tnode->left=tnode->right=NULL;

    return tnode;
}

bst_node* bstInsert(bst_node* tnode,participant_t p)
{
    if(tnode==NULL)
        return newTreeNode(p);

    if(p.xp < tnode->data.xp)
        tnode->left=bstInsert(tnode->left,p);
    else
        tnode->right=bstInsert(tnode->right,p);

    return tnode;
}

void moveToBst(queue_t *q,bst_node **root_lord,bst_node **root_others)
{
    qnode_t *current=q->front;
    while(current)
    {
        if(current->participant.status=='l')
            *root_lord=bstInsert(*root_lord,current->participant);
        else
            *root_others=bstInsert(*root_others,current->participant);
        current=current->next;
    }
}

void sdrToFile(FILE *file, bst_node *root)
{
    if(root)
    {
        sdrToFile(file, root->left);
        sdrToFile(file, root->right);

        fprintf(file, "%s %.2f %d ", root->data.name, root->data.xp, root->data.age);

        if(root->data.status=='l')
            fprintf(file,"LORD");
        else if(root->data.status=='c')
            fprintf(file,"CAVALER");
        else if(root->data.status=='a')
            fprintf(file,"AVENTURIER");

        fprintf(file,"\n");
    }
}

void bstWriteToFile(const char *filename,bst_node *root)
{
    FILE *file=fopen(filename,"wt");
    if(file==NULL)
        printf("eroare fisier bstWriteToFile");

    fprintf(file,"Nume Experienta Varsta Statut_social\n");

    sdrToFile(file,root);

    fclose(file);
}

void bstFree(bst_node *root)
{
    if(root==NULL)
        return;
    bstFree(root->left);
    bstFree(root->right);
    free(root);
}

bst_node* bstMinValNode(bst_node* tnode)
{
    if(tnode==NULL)
        return NULL;
    while(tnode->left!=NULL)
        tnode=tnode->left;
    return tnode;
}

bst_node* bstMaxValNode(bst_node* tnode)
{
    if(tnode==NULL)
        return NULL;
    while(tnode->right!=NULL)
        tnode=tnode->right;
    return tnode;
}

bst_node* bstDelete(bst_node* tnode, participant_t p)
{
    if(tnode==NULL)
        return tnode;

    if(p.xp < tnode->data.xp)
        tnode->left=bstDelete(tnode->left,p);
    else if(p.xp > tnode->data.xp)
        tnode->right=bstDelete(tnode->right,p);
    else
    {
        if(tnode->left==NULL)
        {
            bst_node *temp=tnode;
            tnode=tnode->right;
            free(temp);
            temp=NULL;
            return tnode;
        }
        else if(tnode->right==NULL)
        {
            bst_node *temp=tnode;
            tnode=tnode->left;
            free(temp);
            temp=NULL;
            return tnode;
        }
        bst_node *temp=bstMinValNode(tnode->right);
        copyParticipant(&tnode->data,&temp->data);
        tnode->right=bstDelete(tnode->right,temp->data);
    }
    return tnode;
}

bst_node* bstDelWithInfoFromFile(const char* filename,bst_node* tnode)
{
    FILE* file=fopen(filename,"rt");
    if(file==NULL)
        return NULL;

    participant_t person;
    person.name=NULL;
    char *trash;

    trash=(char*)malloc(64*sizeof(char));
    fgets(trash,64,file);
    free(trash);

    //person.name=(char*)malloc(sizeof(char));

    while(readParticipant(&file,&person)==4)
    {
        tnode=bstDelete(tnode,person);
        if(person.name!=NULL)
        {
            free(person.name);
            person.name=NULL;
        }
    }
    free(person.name);

    fclose(file);
    return tnode;
}