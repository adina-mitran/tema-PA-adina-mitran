#include "ROUTE.h"

void copyRoute(route_t *dest,route_t *src)
{
    if(dest->forests!=NULL)
    {
        free(dest->forests);
        dest->forests=NULL;
    }

    if(src->cnt_forests > 0)
    {
        dest->forests=(int*)malloc((src->cnt_forests)*sizeof(int));
        if(dest->forests==NULL)
        {
            printf("eroare alocare memorie dest->forests");
            return;
        }
        for(int i=0;i<src->cnt_forests;i++)
            dest->forests[i]=src->forests[i];
         dest->cnt_forests=src->cnt_forests;
    }
    else
        dest->cnt_forests=0;
    strcpy(dest->name,src->name);
}

void readRouteFromFile(FILE **file, route_t *route)
{
    int route_length=0;
    char forests[256],temp_forests[256];
    //int temp_forests[256];

    fscanf(*file, "%[^:]: ",route->name);
    fgets(forests,256,*file);

    if(route->forests!=NULL)
    {
        free(route->forests);
        route->forests=NULL;
    }

    strcpy(temp_forests,forests);
    char *p=strtok(temp_forests," \n");
    while(p)
    {
        route_length++;
        p=strtok(NULL," \n");
    }
    if(route_length>0)
    {
        route->forests=(int*)malloc(route_length*sizeof(int));
        if(route->forests==NULL)
        {
            printf("eroare alocare route->forests");
            route->cnt_forests=0;
            return;
        }
        int i=0;
        p=strtok(forests," \n");
        while(p && i<route_length)
        {
            route->forests[i]=atoi(p);
            i++;
            p=strtok(NULL," \n");
        }
    }
    route->cnt_forests=route_length;
}

void freeRoutes(route_t* routes, int no_routes)
{
    if(routes==NULL)
        return;

    for (int i = 0; i < no_routes; i++)
        free(routes[i].forests);

    free(routes);
}