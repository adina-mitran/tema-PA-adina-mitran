#include "QUEUE.h"

queue_t* createQueueFromFile(const char* filename)
{
    FILE* file=fopen(filename,"rt");
    if(file==NULL)
        return NULL;

    participant_t person;
    memset(&person,0,sizeof(participant_t));
    person.name=NULL;

    queue_t *q;
    q=(queue_t*)malloc(sizeof(queue_t));
    q->front=NULL;
    q->rear=NULL;

    char *trash;
    trash=(char*)malloc(64*sizeof(char));
    fgets(trash,64,file);
    free(trash);
    trash=NULL;

    while(readParticipant(&file,&person)==4)
    {
        qnode_t *current=(qnode_t*)malloc(sizeof(qnode_t));
        if(current==NULL)
        {
            if(person.name!=NULL)
            {
                free(person.name);
                person.name=NULL;
            }
            fclose(file);
            return NULL;
        }

        current->participant.name=NULL;
        copyParticipant(&current->participant,&person);
        current->next=NULL;

        if(q->front==NULL)
            q->front=q->rear=current;
        else
        {
            q->rear->next=current;
            q->rear=current;
        }

        if(person.name!=NULL)
        {
            free(person.name);
            person.name=NULL;
        }
    }
    if(person.name!=NULL)
    {
        free(person.name);
        person.name=NULL;
    }
    fclose(file);
    return q;
}

void writeQueueToFile(queue_t *q,const char *filename)
{
    FILE *file=fopen(filename,"wt");
    fprintf(file,"Nume Experienta Varsta Statut_social\n");

    qnode_t *aux;
    aux=q->front;
    while(aux!=NULL)
    {
        fprintf(file,"%s %.2f %d ", aux->participant.name, aux->participant.xp, aux->participant.age);

        if(aux->participant.status=='l')
            fprintf(file,"LORD");
        else if(aux->participant.status=='c')
            fprintf(file,"CAVALER");
        else if(aux->participant.status=='a')
            fprintf(file,"AVENTURIER");
        fprintf(file,"\n");

        aux=aux->next;
    }
    fclose(file);
}

void freeQueue(queue_t *q)
{
    if(q==NULL)
        return;

    qnode_t *current=q->front;
    qnode_t *next;

    while(current!=NULL)
    {
        next=current->next;
        if(current->participant.name!=NULL)
        {
            free(current->participant.name);
            current->participant.name=NULL;
        }

        free(current);
        current=next;
    }

    free(q);
}


