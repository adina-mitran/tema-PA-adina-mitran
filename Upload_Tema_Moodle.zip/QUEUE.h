#ifndef _QUEUE_H_

#define _QUEUE_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "PARTICIPANT.h"

typedef struct qnode_t qnode_t;
typedef struct queue_t queue_t;

struct qnode_t
{
    participant_t participant;
    qnode_t *next;
};

struct queue_t
{
    qnode_t *front,*rear;
};

queue_t* createQueueFromFile(const char* filename);
void writeQueueToFile(queue_t *q,const char *filename);
void freeQueue(queue_t *q);

#endif