#ifndef _PARTICIPANT_H_

#define _PARTICIPANT_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct participant_t participant_t;

enum Status
{
    LORD='l',
    CAVALER='c',
    AVENTURIER='a'
};

struct participant_t
{
    enum Status status;
    char *name;
    float xp;
    int age;
};

void copyParticipant(participant_t *dest,participant_t *src);
int readParticipant(FILE **file,participant_t *p);

void formatName(char *name);
void formatStatus(participant_t *person, char *status);


#endif