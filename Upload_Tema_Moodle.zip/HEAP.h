#ifndef _HEAP_H_

#define _HEAP_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "PARTICIPANT.h"
#include "ROUTE.h"
#include "BST.h"

typedef struct heap_t heap_t;
typedef struct heap_element heap_element;

struct heap_t
{
    heap_element *array;
    int size,capacity;
};

struct heap_element
{
    participant_t participant;
    route_t route;
};


heap_t *createHeap(int capacity);
int leftChild(heap_t *h,int i);
int rightChild(heap_t *h, int i);
void copyHeapArrayElem(heap_element *dest,heap_element *src);
void swapHeapElements(heap_element *dest,heap_element *src);
void heapifyDown(heap_t *h,int i);
void resizeHeap(heap_t *h);
void insertHeapNode(heap_t *h,heap_element x);
void printHeapToFile(const char *filename,heap_t *h);

participant_t getAndDelMaxFromTree(bst_node **root);
void selectParticipantsFromTree(heap_t *h, bst_node **root_lords, bst_node **root_others);

void freeHeap(heap_t *h);

void sortHeap(heap_t *h);
void updateHeapAfterHunt(heap_t *h);

void printWinners(const char *filename, heap_t *h,int win_no);
#endif